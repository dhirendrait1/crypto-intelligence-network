# Crypto Intelligence Network (CIN) — backend scaffold

This is a minimal FastAPI backend scaffold for the Crypto Intelligence Network (CIN). It is not yet the complete intelligence platform. It does not connect to an exchange, wallet, or paid service and cannot execute trades.

## Requirements

Python 3.11+ is recommended. Install dependencies with:

```bash
python -m pip install -r requirements.txt
```

## Run locally

From this `cin` directory:

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

## Endpoints

- `GET /` — service overview and implementation status
- `GET /health` — liveness check
- `GET /ready` — readiness check
- `/docs` — interactive API documentation

## Tests

```bash
python -m pytest -q
```

## Configuration

Runtime variables use the `CIN_` prefix. Paid services and live market data are disabled by default. `.env.example` documents the settings and contains no credentials.

## Implementation status

This is a backend scaffold only. Live market-data ingestion, persistent storage, coin/fundamental screening, technical indicators (including RSI/MACD), market-structure and liquidity analysis, forecasts/targets, alert delivery, and a visual dashboard are **not implemented** yet. The root endpoint reports these as not implemented to avoid implying otherwise.

CIN is limited to research, analysis, monitoring, forecasting, and alerts. It does not execute trades or manage wallets/funds.
