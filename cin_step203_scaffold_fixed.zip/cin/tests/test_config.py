import pytest
from pydantic import ValidationError

from app.core.config import Settings


def test_safe_defaults() -> None:
    settings = Settings(_env_file=None)
    assert settings.env == "development"
    assert settings.allow_paid_services is False
    assert settings.enable_live_market_data is False
    assert settings.request_timeout_seconds == 10.0


def test_api_prefix_normalized() -> None:
    assert Settings(api_prefix=" api/v1", _env_file=None).api_prefix == "/api/v1"


def test_invalid_timeout_rejected() -> None:
    with pytest.raises(ValidationError):
        Settings(request_timeout_seconds=0, _env_file=None)


def test_invalid_environment_rejected() -> None:
    with pytest.raises(ValidationError):
        Settings(env="unknown", _env_file=None)
