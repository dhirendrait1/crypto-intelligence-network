from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app


def test_root_returns_cin_overview_without_not_found() -> None:
    app = create_app(Settings(env="test", _env_file=None))
    with TestClient(app) as client:
        response = client.get("/")
    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "Crypto Intelligence Network (CIN)"
    assert body["docs"] == "/docs"
    assert body["health"] == "/health"
    assert body["capabilities"]["technical_analysis"] == "not_implemented"


def test_openapi_uses_official_cin_name() -> None:
    app = create_app(Settings(env="test", _env_file=None))
    assert app.title == "Crypto Intelligence Network (CIN)"
