from fastapi.testclient import TestClient

from app.core.config import Settings
from app.main import create_app


def test_health_returns_ok() -> None:
    app = create_app(Settings(env="test", _env_file=None))
    with TestClient(app) as client:
        response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "cin"}


def test_ready_returns_ready_after_startup() -> None:
    app = create_app(Settings(env="test", _env_file=None))
    with TestClient(app) as client:
        response = client.get("/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ready", "service": "cin"}


def test_ready_is_not_ready_before_lifespan() -> None:
    app = create_app(Settings(env="test", _env_file=None))
    with TestClient(app, raise_server_exceptions=False) as client:
        # TestClient enters lifespan automatically, so simulate an unready state.
        app.state.ready = False
        response = client.get("/ready")
    assert response.status_code == 503
