import pytest
from fastapi.testclient import TestClient

from app.core.config import Settings
import app.main as main_module


def test_startup_failure_does_not_report_ready(monkeypatch: pytest.MonkeyPatch) -> None:
    async def fail_startup(app) -> None:
        raise RuntimeError("synthetic startup failure")

    monkeypatch.setattr(main_module, "initialize_required_components", fail_startup)
    app = main_module.create_app(Settings(env="test", _env_file=None))
    with pytest.raises(RuntimeError, match="synthetic startup failure"):
        with TestClient(app):
            pass
    assert app.state.ready is False


def test_shutdown_resets_readiness(monkeypatch: pytest.MonkeyPatch) -> None:
    app = main_module.create_app(Settings(env="test", _env_file=None))
    with TestClient(app):
        assert app.state.ready is True
    assert app.state.ready is False
    assert app.state.components_initialized is False
