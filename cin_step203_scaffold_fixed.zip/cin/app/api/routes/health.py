"""Liveness and readiness endpoints."""
from fastapi import APIRouter, HTTPException, Request, status

router = APIRouter(tags=["system"])


@router.get("/health", summary="Liveness probe")
async def health() -> dict[str, str]:
    """Report process responsiveness; intentionally independent of providers."""
    return {"status": "ok", "service": "cin"}


@router.get("/ready", summary="Readiness probe")
async def ready(request: Request) -> dict[str, str]:
    """Report readiness only after required startup initialization completes."""
    if not getattr(request.app.state, "ready", False):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"status": "not_ready", "service": "cin"},
        )
    return {"status": "ready", "service": "cin"}
