"""Crypto Intelligence Network (CIN) application package."""
