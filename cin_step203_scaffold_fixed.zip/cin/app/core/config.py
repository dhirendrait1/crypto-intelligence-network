"""Validated runtime configuration for CIN."""
from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Settings are loaded from environment variables over safe defaults."""

    model_config = SettingsConfigDict(
        env_prefix="CIN_",
        case_sensitive=False,
        extra="ignore",
        validate_default=True,
    )

    env: Literal["development", "test", "staging", "production"] = "development"
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    api_prefix: str = "/api/v1"
    request_timeout_seconds: float = Field(default=10.0, gt=0, le=120)
    max_retries: int = Field(default=2, ge=0, le=10)
    max_concurrent_reports: int = Field(default=2, ge=1, le=20)
    allow_paid_services: bool = False
    enable_live_market_data: bool = False

    @field_validator("api_prefix")
    @classmethod
    def normalize_api_prefix(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("API prefix cannot be empty")
        if not value.startswith("/"):
            value = "/" + value
        return value.rstrip("/") or "/"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings for normal application startup."""
    return Settings()
