"""Minimal structured logging configuration with secret-safe defaults."""
import json
import logging
from datetime import datetime, timezone


class JsonFormatter(logging.Formatter):
    """Format log records as compact JSON without dumping arbitrary objects."""

    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            # Do not include exception text/tracebacks by default; callers may log
            # a safe error code separately.
            payload["exception"] = "exception details suppressed"
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def configure_logging(level: str = "INFO") -> None:
    """Configure a single JSON stream handler for application logs."""
    root = logging.getLogger()
    root.setLevel(level)
    handler = next((h for h in root.handlers if getattr(h, "_cin_json_handler", False)), None)
    if handler is None:
        handler = logging.StreamHandler()
        handler._cin_json_handler = True  # type: ignore[attr-defined]
        root.addHandler(handler)
    handler.setFormatter(JsonFormatter())
