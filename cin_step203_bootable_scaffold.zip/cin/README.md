# Crypto Intelligence Engine (CIN) — first scaffold

Minimal FastAPI scaffold for research/intelligence workflows. This initial build does not connect to an exchange, a wallet, or any paid service and cannot execute trades.

## Requirements

Python 3.11+ is recommended. Install the pinned dependencies with:

```bash
python -m pip install -r requirements.txt
```

## Test

```bash
python -m pytest -q
```

## Run

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Check `http://127.0.0.1:8000/health` and `http://127.0.0.1:8000/ready`.

## Configuration

Runtime variables use the `CIN_` prefix. Paid services and live market data are disabled by default. `.env.example` documents the settings; it contains no credentials.

## Status

This is the first local scaffold only. It does not yet implement Coinbase ingestion, persistent market storage, indicators, predictions, alert delivery, or a dashboard.
