"""FastAPI application factory and startup/shutdown lifecycle."""
import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI

from app.api.routes.health import router as health_router
from app.core.config import Settings, get_settings
from app.core.errors import unhandled_exception_handler
from app.core.logging import configure_logging

logger = logging.getLogger("cin.lifecycle")


async def initialize_required_components(app: FastAPI) -> None:
    """Initialize mandatory scaffold components; no network calls at this stage."""
    # Future mandatory local resources should be initialized here, with bounded
    # startup behavior. Public exchange access is intentionally not performed.
    app.state.components_initialized = True


async def shutdown_components(app: FastAPI) -> None:
    """Release initialized resources. Currently the scaffold owns no clients."""
    app.state.components_initialized = False


def create_app(settings: Settings | None = None) -> FastAPI:
    """Create an independently testable CIN FastAPI application."""
    runtime_settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.ready = False
        configure_logging(runtime_settings.log_level)
        try:
            await initialize_required_components(app)
            app.state.ready = True
            logger.info("CIN application startup completed")
            yield
        except Exception:
            app.state.ready = False
            logger.error("CIN application startup or runtime lifecycle failed")
            raise
        finally:
            app.state.ready = False
            await shutdown_components(app)
            logger.info("CIN application shutdown completed")

    application = FastAPI(
        title="Crypto Intelligence Engine",
        version="0.1.0",
        description="Research, analysis, monitoring and alerts; no trade execution.",
        lifespan=lifespan,
    )
    application.state.ready = False
    application.state.settings = runtime_settings
    application.include_router(health_router)
    application.add_exception_handler(Exception, unhandled_exception_handler)
    return application


app = create_app()
