"""Crypto Intelligence Engine application package."""
